

export enum  ZoomMode {
    ExTENT = "extent",
    FIXED = "fixed"
}
// export type  MapViewMode =  "HEADLESS" | "HEADED"
 
// export enum  MapViewMode {
//     HEADLESS = "HEADLESS",
//     HEADED = "HEADED"
// }